-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2016 at 07:47 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `appoinment`
--

CREATE TABLE `appoinment` (
  `id` int(10) NOT NULL,
  `docid` int(10) NOT NULL,
  `docname` varchar(30) NOT NULL,
  `problem` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `time` time(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appoinment`
--

INSERT INTO `appoinment` (`id`, `docid`, `docname`, `problem`, `status`, `date`, `time`) VALUES
(1, 1, 'sk', 'eye problem', 'bad', '2016-12-28', '01:50:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `bed1`
--

CREATE TABLE `bed1` (
  `id` int(20) NOT NULL,
  `patname` varchar(30) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bed1`
--

INSERT INTO `bed1` (`id`, `patname`, `date`) VALUES
(1, 'tr', '2016-12-22'),
(2, 'fg', '2016-12-13'),
(3, '', '0000-00-00'),
(4, '', '0000-00-00'),
(5, '', '0000-00-00'),
(6, '', '0000-00-00'),
(7, '', '0000-00-00'),
(8, '', '0000-00-00'),
(9, 'dg', '2016-12-20'),
(10, '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `bed2`
--

CREATE TABLE `bed2` (
  `id` int(20) NOT NULL,
  `patname` varchar(30) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bed2`
--

INSERT INTO `bed2` (`id`, `patname`, `date`) VALUES
(1, 'mk', '2016-12-15'),
(2, '', '0000-00-00'),
(3, '', '0000-00-00'),
(4, '', '0000-00-00'),
(5, '', '0000-00-00'),
(6, '', '0000-00-00'),
(7, '', '0000-00-00'),
(8, '', '0000-00-00'),
(9, '', '0000-00-00'),
(10, '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `id` int(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `docfee` int(30) NOT NULL,
  `medfee` int(30) NOT NULL,
  `bedfee` int(30) NOT NULL,
  `bldfee` int(30) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`id`, `name`, `docfee`, `medfee`, `bedfee`, `bldfee`, `date`) VALUES
(1, 'jcj', 500, 700, 500, 0, '2016-12-22');

-- --------------------------------------------------------

--
-- Table structure for table `birth`
--

CREATE TABLE `birth` (
  `id` int(20) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `place` varchar(30) NOT NULL,
  `mothername` varchar(30) NOT NULL,
  `fathername` varchar(30) NOT NULL,
  `number` int(20) NOT NULL,
  `bldgrp` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `birth`
--

INSERT INTO `birth` (`id`, `date`, `time`, `place`, `mothername`, `fathername`, `number`, `bldgrp`, `gender`) VALUES
(1, '2016-12-08', '03:00:00', 'mirpur', 'mk', 'sk', 45673, 'a(+ve)', 'female'),
(2, '2016-12-05', '13:59:00', 'dhaka', 'hbf', 'fnbwen', 35328, 'b-', 'djndj');

-- --------------------------------------------------------

--
-- Table structure for table `blood`
--

CREATE TABLE `blood` (
  `id` int(40) NOT NULL,
  `group` varchar(50) NOT NULL,
  `prebld` int(40) NOT NULL,
  `usebld` int(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blood`
--

INSERT INTO `blood` (`id`, `group`, `prebld`, `usebld`) VALUES
(1, 'A+', 56, 10),
(2, 'A-', 54, 10),
(3, 'B+', 57, 12),
(4, 'B-', 60, 32),
(5, 'O+', 55, 30),
(6, 'O-', 50, 21),
(7, 'AB+', 65, 25),
(8, 'AB-', 56, 15);

-- --------------------------------------------------------

--
-- Table structure for table `death`
--

CREATE TABLE `death` (
  `id` int(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `bdate` date NOT NULL,
  `ddate` date NOT NULL,
  `dtime` time NOT NULL,
  `number` int(20) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `bdi` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `death`
--

INSERT INTO `death` (`id`, `name`, `bdate`, `ddate`, `dtime`, `number`, `gender`, `bdi`) VALUES
(1, 'mk', '1996-08-14', '2016-12-14', '19:00:00', 56834, 'female', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `diagnosis`
--

CREATE TABLE `diagnosis` (
  `id` int(20) NOT NULL,
  `patname` varchar(50) NOT NULL,
  `problem` varchar(50) NOT NULL,
  `diagnosis` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `contact` int(20) NOT NULL,
  `report` varchar(50) NOT NULL,
  `takeby` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `specification` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `name`, `specification`) VALUES
(1, 'mk', 'eye'),
(2, 'sk', 'brain');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `age` int(10) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `occupation` varchar(30) NOT NULL,
  `mobile` int(15) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `name`, `age`, `gender`, `occupation`, `mobile`, `address`) VALUES
(1, 'raka', 20, 'female', 'student', 657643, 'rupnagar,dkaka'),
(2, 'mk', 21, 'female', 'teacher', 145236546, 'mirpur,dhaka');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `id` int(10) NOT NULL,
  `medicine` varchar(50) NOT NULL,
  `diagnosis` varchar(50) NOT NULL,
  `instruction` varchar(50) NOT NULL,
  `docname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`id`, `medicine`, `diagnosis`, `instruction`, `docname`) VALUES
(1, 'napa\r\nriz', 'blood test', 'take rest', 'sk'),
(2, 'parasitamol', 'citi scan', 'rets', 'mrk'),
(3, 'gsxh', 'dxhjw', 'jdxj', '1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`) VALUES
('mk', '123'),
('mm', '789'),
('sk', '456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appoinment`
--
ALTER TABLE `appoinment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bed1`
--
ALTER TABLE `bed1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bed2`
--
ALTER TABLE `bed2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `birth`
--
ALTER TABLE `birth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blood`
--
ALTER TABLE `blood`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `death`
--
ALTER TABLE `death`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `diagnosis`
--
ALTER TABLE `diagnosis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appoinment`
--
ALTER TABLE `appoinment`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `birth`
--
ALTER TABLE `birth`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `blood`
--
ALTER TABLE `blood`
  MODIFY `id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `death`
--
ALTER TABLE `death`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `diagnosis`
--
ALTER TABLE `diagnosis`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
