<?php
$host='localhost';
$username='root';
$password='';
$dbname='hms';
$con=mysql_connect($host,$username,$password);
mysql_select_db($dbname);
$epr='';
$msg='';
if(isset($_GET['epr']))
	$epr=$_GET['epr'];
//*****save record******
if($epr=='save')
{
	
	$patname=$_POST['txtpatname'];
	$problem=$_POST['txtproblem'];
	$diagnosis=$_POST['txtdiagnosis'];
	$date=$_POST['txtdate'];
	$contact=$_POST['txtcontact'];
	$report=$_POST['txtreport'];
	$takeby=$_POST['txttakeby'];
	$a_sql=mysql_query("INSERT INTO diagnosis VALUES('', '$patname', '$problem', '$diagnosis', '$date', '$contact', '$report', '$takeby') ");
	if($a_sql)
		header("location:diagnosis.php");
	else
		$msg='Error : '.mysql_error();
}
//*****save update******
if($epr=='saveup')
{
	$id=$_POST['txtid'];
	$report=$_POST['txtreport'];
	$takeby=$_POST['txttakeby'];
	$a_sql=mysql_query("UPDATE diagnosis SET report='$report',takeby='$takeby' where id='$id'");
	if($a_sql)
		header("location:diagnosis.php");
	else
		$msg='Error : '.mysql_error();
}

?>
<html>
<head>
</head>
<body>
<?php
if($epr=='update'){
	$id=$_GET['id'];
	$row=mysql_query("SELECT * FROM diagnosis where id='$id'");
	$st_row=mysql_fetch_array($row);
?>
<h2 align="center">Update Report</h2>
<form method="Post" action='diagnosis.php?epr=saveup'>
	<table align='center'>
	<tr>
		<td>Report: </td>
		<td><input type='text' name='txtreport' value="<?php echo $st_row['report'] ?>"/></td>
	</tr>
	<tr>
		<td>Taken By: </td>
		<td><input type='text' name='txttakeby' value="<?php echo $st_row['takeby'] ?>"/></td>
	</tr>
	<tr>
		<td></td>
		<td><input type='submit' name='btnsave'/></td>
	</tr>
	</table>
</form>
	
<?php }else{ ?>
<h2 align="center">Add Student</h2>
<form method="Post" action='diagnosis.php?epr=save'>
	<table align='center'>
	<tr>
		<td>Id: </td>
		<td><input type='text' name='txtid'/></td>
	</tr>
	<tr>
		<td>Patient Name: </td>
		<td><input type='text' name='txtpatname'/></td>
	</tr>
	<tr>
		<td>Problem: </td>
		<td><input type='text' name='txtproblem'/></td>
	</tr>
	<tr>
		<td>Diagnosis: </td>
		<td><input type='text' name='txtdiagnosis'/></td>
	</tr>
	<tr>
		<td>Date: </td>
		<td><input type='date' name='txtdate'/></td>
	</tr>
	<tr>
		<td>Contact: </td>
		<td><input type='text' name='txtcontact'/></td>
	</tr>
	<tr>
		<td>Report: </td>
		<td><input type='text' name='txtreport' value='not collected'/></td>
	</tr>
	<tr>
		<td>Taken By: </td>
		<td><input type='text' name='txttakeby'value='empty'/></td>
	</tr>
	<tr>
		<td></td>
		<td><input type='submit' name='btnsave'/></td>
	</tr>
	</table>
</form>
<?php } ?>
<!--********show record*******-->
<h2 align="center">Report List</h2>
<table align="center" border="1" cellspacing="0" cellpadding="0" width="700">
<thead>
	<th>Id</th>
	<th>Patient Name</th>
	<th>Problem</th>
	<th>Diagnosis</th>
	<th>Date</th>
	<th>Contact</th>
	<th>Report</th>
	<th>Taken By</th>
	<th>Action</th>
</thead>
<?php
$host='localhost';
$username='root';
$password='';
$dbname='hms';
$con=mysql_connect($host,$username,$password);
mysql_select_db($dbname);
$sql=mysql_query("SELECT * FROM diagnosis");
$sno=1;
	while($row=mysql_fetch_array($sql)){
		echo "<tr>
		<td>".$sno."</td> 
		<td>".$row['patname']."</td>
		<td>".$row['problem']."</td>
		<td>".$row['diagnosis']."</td>
		<td>".$row['date']."</td>
		<td>".$row['contact']."</td>
		<td>".$row['report']."</td>
		<td>".$row['takeby']."</td>
		<td align='center'>
			<a href='diagnosis.php?epr=update&id=".$row['id']."''>UPDATE</a>
		</td>
		</tr>";
	$sno++;
}

?>
</table>
<?php echo $msg; ?>
</body>
</html>