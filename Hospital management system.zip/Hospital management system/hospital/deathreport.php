<html> 
 <head>
 </head> 
<body style="background-image:url(background4.jpg)"> 
<big><big><center>HOSPITAL&nbsp; MANAGEMENT SYSTEM<center><br>
<br>
<br>
</big></big>
<center>
<h2 align="center">Add Report</h2>
<form method="Post" action='deathreport.php?epr=save'>
	<table align='center'>
	<tr>
		<td>Id: </td>
		<td><input type='text' name='txtid'/></td>
	</tr>
	<tr>
		<td>Name: </td>
		<td><input type='text' name='txtname'/></td>
	</tr>
	<tr>
		<td>Date of Birth: </td>
		<td><input type='date' name='txtbdate'/></td>
	</tr>
	<tr>
		<td>Date of Death: </td>
		<td><input type='date' name='txtddate'/></td>
	</tr>
	<tr>
		<td>Time of Death: </td>
		<td><input type='time' name='txtdtime'/></td>
	</tr>
	<tr>
		<td>Relative's Number: </td>
		<td><input type='text' name='txtnumber'/></td>
	</tr>
	<tr>
		<td>Gender: </td>
		<td><input type='text' name='txtgender'/></td>
	</tr>
	<tr>
		<td>Body Issued: </td>
		<td><input type='text' name='txtbdi'/></td>
	</tr>
	<tr>
		<td></td>
		<td><input type='submit' name='btnsave'/></td>
	</tr>
	</table>
</form>
<h2 align="center">Death Report Details</h2>
<table align="center" border="1" cellspacing="0" cellpadding="0" width="1000">
<thead>
	<th>Id</th>
	<th>Name</th>
	<th>Date of Birth</th>
	<th>Date of Death</th>
	<th>Time of Death</th>
	<th>Relative Contact Number</th>
	<th>Gender</th>
	<th>Body Issued</th>
</thead>
</body>
</html>
<?php
$host='localhost';
$username='root';
$password='';
$dbname='hms';
$con=mysql_connect($host,$username,$password);
mysql_select_db($dbname);
$epr='';
$msg='';
if(isset($_GET['epr']))
	$epr=$_GET['epr'];
$sql=mysql_query("SELECT * FROM death");
	while($row=mysql_fetch_array($sql)){
		echo "<tr>
		<td>".$row['id']."</td>
		<td>".$row['name']."</td>
		<td>".$row['bdate']."</td>
		<td>".$row['ddate']."</td>
		<td>".$row['dtime']."</td>
		<td>".$row['number']."</td>
		<td>".$row['gender']."</td>
		<td>".$row['bdi']."</td>
		</tr>";
}
//*****save record******
if($epr=='save')
{
	$id=$_POST['txtid'];
	$name=$_POST['txtname'];
	$bdate=$_POST['txtbdate'];
	$ddate=$_POST['txtddate'];
	$dtime=$_POST['txtdtime'];
	$number=$_POST['txtnumber'];
	$gender=$_POST['txtgender'];
	$bdi=$_POST['txtbdi'];
	$a_sql=mysql_query("INSERT INTO death VALUES('','$name','$bdate','$ddate','$dtime','$number','$gender','$bdi')");
	if($a_sql)
		header("location:deathreport.php");
	else
		$msg='Error : '.mysql_error();
}


?>
</table>

<br>
<br>
<br>
<a href="home.html"><b>HOME</b></a>