<?php
session_start()
?>

<?php
$id=$_POST['id'];
$name=$_POST['name'];
$specification=$_POST['specification'];
$con=@mysql_connect("localhost","root","") or die(mysql_error());
$db=@mysql_select_db("hms",$con)or die(mysql_error());
$str="insert into doctors values('','$name','$specification')";
$res=@mysql_query($str)or die(mysql_error());
if($res>=0)
{
echo'<br><br><b>Doctor added !!<br>';
}

?>
<html>
<body style="background-image:url(background4.jpg)">
<br>
<a href="home.html"><b>Click here to return to the home page</b></a>
</body></html>
