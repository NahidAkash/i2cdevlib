<?php 
$rno=$_GET['rno']; 
if(!mysql_connect("localhost","root","")) 
{ 
 echo "<tr><td><font color=red size=4>Connection 
Error</font></td></tr>"; 
 die(); 
} 
$sql = "SELECT * from doct where dno='".$rno."'";
mysql_select_db("hms"); 
$rs1=mysql_query($sql, $connection); 
$sno=1; 
while( $row=mysql_fetch_array($rs1)) { 
 echo "<tr bgcolor=blue><td ><font size=4 color=white>Edit Patient 
Details</font></td></tr>"; 
 echo "<form name=fdmod method=post action=patmod.php>"; 
 echo "<tr><td><table width=750 cellspacing=0 cellpadding=5>"; 
 echo "<tr><td>Patient Name</td><td><input type=text name=name 
size=30 maxlength=30 value='".$row[1]."'></td></tr>"; 
 echo "<tr><td>Age</td><td><input type=text name=age 
size=30 maxlength=30  value='".$row[2]."'></td></tr>"; 
echo "<tr><td>Gender</td><td><input type=text name=gender 
size=30 maxlength=30 value='".$row[3]."'></td></tr>";
echo "<tr><td>Occupation</td><td><input type=text name=occup 
size=30 maxlength=30 value='".$row[4]."'></td></tr>";
echo "<tr><td>Mobile</td><td><input type=text name=mob 
size=30 maxlength=30 value='".$row[5]."'></td></tr>";
echo "<tr><td>Address</td><td><input type=text name=addr 
size=30 maxlength=30 value='".$row[6]."'></td></tr>";
 echo "</table></td></tr>"; 
 echo "<tr><td colspan=2 align=center><input type=hidden name=rno 
value=".$rno."><input type=submit value=Submit></td></tr>"; 
 echo "</form>"; 
 $sno++; 
} 
if ($sno==1) echo "<tr><td align=center><font size=4 color=red>Records 
Not Found</font></td></tr>"; 
?> 