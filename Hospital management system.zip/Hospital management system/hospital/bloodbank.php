<?php
$host='localhost';
$username='root';
$password='';
$dbname='hms';
$con=mysql_connect($host,$username,$password);
mysql_select_db($dbname);
$epr='';
$msg='';
if(isset($_GET['epr']))
	$epr=$_GET['epr'];
//*****save update******
if($epr=='saveup')
{
	$id=$_POST['txtid'];
	$group=$_POST['txtgroup'];
	$prebld=$_POST['txtprebld'];
	$usebld=$_POST['txtusebld'];
	$a_sql=mysql_query("UPDATE blood SET prebld='$prebld',usebld='$usebld' where id='$id'");
	if($a_sql)
		header("location:bloodbank.php");
	else
		$msg='Error : '.mysql_error();
}

?>
<html>
<head>
</head>
<body style="background-image:url(background4.jpg)">
<?php
if($epr=='update'){
	$id=$_GET['id'];
	$row=mysql_query("SELECT * FROM blood where id='$id'");
	$st_row=mysql_fetch_array($row);
?>
<h2 align="center">Update Student</h2>
<form method="Post" action='bloodbank.php?epr=saveup'>
	<table align='center'>
	<tr>
		<td>Id: </td>
		<td><input type='text' name='txtid' value="<?php echo $st_row['id'] ?>"/></td>
	</tr>
	<tr>
		<td>Group: </td>
		<td><input type='text' name='txtgroup' value="<?php echo $st_row['group'] ?>"/></td>
	</tr>
	<tr>
		<td>Present Blood Packet: </td>
		<td><input type='text' name='txtprebld' value="<?php echo $st_row['prebld'] ?>"/></td>
	</tr>
	<tr>
		<td>Used Blood Packet: </td>
		<td><input type='text' name='txtusebld' value="<?php echo $st_row['usebld'] ?>"/></td>
	</tr>
	<tr>
		<td></td>
		<td><input type='submit' name='btnsave'/></td>
	</tr>
	</table>
</form>
	
<?php }else{ ?>

<?php } ?>
<!--********show record*******-->
<h2 align="center">Blood Packet List</h2>
<table align="center" border="1" cellspacing="0" cellpadding="0" width="700">
<thead>
	<th>Id</th>
	<th>Blood Group</th>
	<th>Qty of Present Blood Packet</th>
	<th>Qty of Present Blood Packet</th>
	<th>Action</th>
</thead>
<?php
$host='localhost';
$username='root';
$password='';
$dbname='hms';
$con=mysql_connect($host,$username,$password);
mysql_select_db($dbname);
$sql=mysql_query("SELECT * FROM blood");
$sno=1;
	while($row=mysql_fetch_array($sql)){
		echo "<tr>
		<td>".$sno."</td> 
		<td>".$row['group']."</td>
		<td>".$row['prebld']."</td>
		<td>".$row['usebld']."</td>
		<td align='center'>
			<a href='bloodbank.php?epr=update&id=".$row['id']."''>UPDATE</a>
		</td>
		</tr>";
	$sno++;
}

?>
</table>
<?php echo $msg; ?>
</body>
</html>
<br>
<br>
<br>
<center><a href="home.html"><b>BACK</b></a></center>