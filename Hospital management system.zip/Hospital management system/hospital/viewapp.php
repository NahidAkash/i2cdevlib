<html> 
 <head>
 </head> 
<body style="background-image:url(background4.jpg)"> 
<big><big><center>HOSPITAL&nbsp; MANAGEMENT SYSTEM<center><br>
<br>
<br>
</big></big>
<center>
<h2 align="center">Appoinment List</h2>
<table align="center" border="1" cellspacing="0" cellpadding="0" width="700">
<thead>
	<th>Patient Id</th>
	<th>Doctor Id</th>
	<th>Doctor Name</th>
	<th>Problem</th>
	<th>Status</th>
	<th>Date</th>
	<th>Time</th>
	<th>Action</th>
</thead>
</body>
</html>
<?php
$host='localhost';
$username='root';
$password='';
$dbname='hms';
$con=mysql_connect($host,$username,$password);
mysql_select_db($dbname);
$epr='';
$msg='';
if(isset($_GET['epr']))
	$epr=$_GET['epr'];
$sql=mysql_query("SELECT * FROM appoinment");
	while($row=mysql_fetch_array($sql)){
		echo "<tr>
		<td>".$row['id']."</td>
		<td>".$row['docid']."</td>
		<td>".$row['docname']."</td>
		<td>".$row['problem']."</td>
		<td>".$row['status']."</td>
		<td>".$row['date']."</td>
		<td>".$row['time']."</td>
		<td align='center'>
			<a href='viewapp.php?epr=delete&id=".$row['id']."'>DELETE</a> | 
			<a href='viewapp.php?epr=update&id=".$row['id']."'>UPDATE</a>
		</td>
		</tr>";
}
//*****delete record*****
if($epr=='delete')
{
	$id=$_GET['id'];
	$delete=mysql_query("DELETE FROM appoinment where id=$id");
	if($delete)
		header("location:viewapp.php");
	else
		$msg='Error : '.mysql_error();
}
//*****save update******
if($epr=='saveup')
{
	$id=$_POST['txtid'];
	$docid=$_POST['txtdocid'];
	$docname=$_POST['txtdocname'];
	$problem=$_POST['txtproblem'];
	$status=$_POST['txtstatus'];
	$date=$_POST['txtdate'];
	$time=$_POST['txttime'];
	$a_sql=mysql_query("UPDATE appoinment SET docid='$docid',docname='$docname',problem='$problem',status='$status',date='$date',time='$time' where id='$id'");
	if($a_sql)
		header("location:viewapp.php");
	else
		$msg='Error : '.mysql_error();
}


?>
</table>
<?php
if($epr=='update'){
	$id=$_GET['id'];
	$row=mysql_query("SELECT * FROM appoinment where id='$id'");
	$st_row=mysql_fetch_array($row);
?>
<h2 align="center">Update Appoinment</h2>
<form method="Post" action='viewapp.php?epr=saveup'>
	<table align='center'>
	<tr>
		<td>Id: </td>
		<td><input type='text' name='txtid' value="<?php echo $st_row['id'] ?>"/></td>
	</tr>
	<tr>
		<td>Doctor Id: </td>
		<td><input type='text' name='txtdocid' value="<?php echo $st_row['docid'] ?>"/></td>
	</tr>
	<tr>
		<td>Doctor Name: </td>
		<td><input type='text' name='txtdocname' value="<?php echo $st_row['docname'] ?>"/></td>
	</tr>
	<tr>
		<td>Problem: </td>
		<td><input type='text' name='txtproblem' value="<?php echo $st_row['problem'] ?>"/></td>
	</tr>
	<tr>
		<td>Status: </td>
		<td><input type='text' name='txtstatus' value="<?php echo $st_row['status'] ?>"/></td>
	</tr>
	<tr>
		<td>Date: </td>
		<td><input type='date' name='txtdate' value="<?php echo $st_row['date'] ?>"/></td>
	</tr>
	<tr>
		<td>Time: </td>
		<td><input type='time' name='txttime' value="<?php echo $st_row['time'] ?>"/></td>
	</tr>
	<tr>
		<td></td>
		<td><input type='submit' name='btnsave'/></td>
	</tr>
	</table>
</form>
<?php }else{ ?>

<?php } ?>

<br>
<br>
<br>
<a href="appoinment.html"><b>BACK</b></a>