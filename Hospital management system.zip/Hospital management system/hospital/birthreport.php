<html> 
 <head>
 </head> 
<body style="background-image:url(background4.jpg)"> 
<big><big><center>HOSPITAL&nbsp; MANAGEMENT SYSTEM<center><br>
<br>
<br>
</big></big>
<center>
<h2 align="center">Add Report</h2>
<form method="Post" action='birthreport.php?epr=save'>
	<table align='center'>
	<tr>
		<td>Id: </td>
		<td><input type='text' name='txtid'/></td>
	</tr>
	<tr>
		<td>Date: </td>
		<td><input type='date' name='txtdate'/></td>
	</tr>
	<tr>
		<td>Time: </td>
		<td><input type='time' name='txttime'/></td>
	</tr>
	<tr>
		<td>Place: </td>
		<td><input type='text' name='txtplace'/></td>
	</tr>
	<tr>
		<td>Mother's Name: </td>
		<td><input type='text' name='txtmothername'/></td>
	</tr>
	<tr>
		<td>Father's Name: </td>
		<td><input type='text' name='txtfathername'/></td>
	</tr>
	<tr>
		<td>Parent's Number: </td>
		<td><input type='text' name='txtnumber'/></td>
	</tr>
	<tr>
		<td>Blood Group: </td>
		<td><input type='text' name='txtbldgrp'/></td>
	</tr>
	<tr>
		<td>Gender: </td>
		<td><input type='text' name='txtgender'/></td>
	</tr>
	<tr>
		<td></td>
		<td><input type='submit' name='btnsave'/></td>
	</tr>
	</table>
</form>
<h2 align="center">Birth Report Details</h2>
<table align="center" border="1" cellspacing="0" cellpadding="0" width="1000">
<thead>
	<th>Id</th>
	<th>Date</th>
	<th>Time</th>
	<th>Place</th>
	<th>Mother's Name</th>
	<th>Father's Name</th>
	<th>Parents Contact Number</th>
	<th>Blood Group</th>
	<th>Gender</th>
</thead>
</body>
</html>
<?php
$host='localhost';
$username='root';
$password='';
$dbname='hms';
$con=mysql_connect($host,$username,$password);
mysql_select_db($dbname);
$epr='';
$msg='';
if(isset($_GET['epr']))
	$epr=$_GET['epr'];
$sql=mysql_query("SELECT * FROM birth");
	while($row=mysql_fetch_array($sql)){
		echo "<tr>
		<td>".$row['id']."</td>
		<td>".$row['date']."</td>
		<td>".$row['time']."</td>
		<td>".$row['place']."</td>
		<td>".$row['mothername']."</td>
		<td>".$row['fathername']."</td>
		<td>".$row['number']."</td>
		<td>".$row['bldgrp']."</td>
		<td>".$row['gender']."</td>
		</tr>";
}
//*****save record******
if($epr=='save')
{
	$id=$_POST['txtid'];
	$date=$_POST['txtdate'];
	$time=$_POST['txttime'];
	$place=$_POST['txtplace'];
	$mothername=$_POST['txtmothername'];
	$fathername=$_POST['txtfathername'];
	$number=$_POST['txtnumber'];
	$bldgrp=$_POST['txtbldgrp'];
	$gender=$_POST['txtgender'];
	$a_sql=mysql_query("INSERT INTO birth VALUES('','$date','$time','$place','$mothername','$fathername','$number','$bldgrp','$gender')");
	if($a_sql)
		header("location:birthreport.php");
	else
		$msg='Error : '.mysql_error();
}


?>
</table>

<br>
<br>
<br>
<a href="home.html"><b>HOME</b></a>