<?php
$host='localhost';
$username='root';
$password='';
$dbname='std';
$con=mysql_connect($host,$username,$password);
mysql_select_db($dbname);
$epr='';
$msg='';
if(isset($_GET['epr']))
	$epr=$_GET['epr'];
//*****save record******
if($epr=='save')
{
	$name=$_POST['txtname'];
	$gender=$_POST['txtgender'];
	$addr=$_POST['txtaddr'];
	$a_sql=mysql_query("INSERT INTO student VALUES('','$name','$gender','$addr')");
	if($a_sql)
		header("location:index.php");
	else
		$msg='Error : '.mysql_error();
}
//*****delete record*****
if($epr=='delete')
{
	$id=$_GET['id'];
	$delete=mysql_query("DELETE FROM student where student_id=$id");
	if($delete)
		header("location:index.php");
	else
		$msg='Error : '.mysql_error();
}
//*****save update******
if($epr=='saveup')
{
	$id=$_POST['txtid'];
	$name=$_POST['txtname'];
	$gender=$_POST['txtgender'];
	$addr=$_POST['txtaddr'];
	$a_sql=mysql_query("UPDATE student SET name='$name',gender='$gender',addr='$addr' where student_id='$id'");
	if($a_sql)
		header("location:index.php");
	else
		$msg='Error : '.mysql_error();
}

?>
<html>
<head>
</head>
<body>
<?php
if($epr=='update'){
	$id=$_GET['id'];
	$row=mysql_query("SELECT * FROM student where student_id='$id'");
	$st_row=mysql_fetch_array($row);
?>
<h2 align="center">Update Student</h2>
<form method="Post" action='index.php?epr=saveup'>
	<table align='center'>
	<tr>
		<td>Id: </td>
		<td><input type='text' name='txtid' value="<?php echo $st_row['student_id'] ?>"/></td>
	</tr>
	<tr>
		<td>Name: </td>
		<td><input type='text' name='txtname' value="<?php echo $st_row['name'] ?>"/></td>
	</tr>
	<tr>
		<td>Gender: </td>
		<td><input type='text' name='txtgender' value="<?php echo $st_row['gender'] ?>"/></td>
	</tr>
	<tr>
		<td>Address: </td>
		<td><input type='text' name='txtaddr' value="<?php echo $st_row['addr'] ?>"/></td>
	</tr>
	<tr>
		<td></td>
		<td><input type='submit' name='btnsave'/></td>
	</tr>
	</table>
</form>
	
<?php }else{ ?>
<h2 align="center">Add Student</h2>
<form method="Post" action='index.php?epr=save'>
	<table align='center'>
	<tr>
		<td>Name: </td>
		<td><input type='text' name='txtname'/></td>
	</tr>
	<tr>
		<td>Gender: </td>
		<td><input type='text' name='txtgender'/></td>
	</tr>
	<tr>
		<td>Address: </td>
		<td><input type='text' name='txtaddr'/></td>
	</tr>
	<tr>
		<td></td>
		<td><input type='submit' name='btnsave'/></td>
	</tr>
	</table>
</form>
<?php } ?>
<!--********show record*******-->
<h2 align="center">Report List</h2>
<table align="center" border="1" cellspacing="0" cellpadding="0" width="700">
<thead>
	<th>Id</th>
	<th>Patient Name</th>
	<th>Problem</th>
	<th>Diagnosis</th>
	<th>Date</th>
	<th>Contact</th>
	<th>Report</th>
	<th>Taken By</th>
	<th>Action</th>
</thead>
<?php
$host='localhost';
$username='root';
$password='';
$dbname='hms';
$con=mysql_connect($host,$username,$password);
mysql_select_db($dbname);
$sql=mysql_query("SELECT * FROM diagnosis");
$sno=1;
	while($row=mysql_fetch_array($sql)){
		echo "<tr>
		<td>".$sno."</td> 
		<td>".$row['patname']."</td>
		<td>".$row['problem']."</td>
		<td>".$row['diagnosis']."</td>
		<td>".$row['date']."</td>
		<td>".$row['contact']."</td>
		<td>".$row['report']."</td>
		<td>".$row['takeby']."</td>
			<a href='index.php?epr=update&id=".$row['id']."''>UPDATE</a>
		</td>
		</tr>";
	$sno++;
}

?>
</table>
<?php echo $msg; ?>
</body>
</html>