<html> 
 <head>
 </head> 
<body style="background-image:url(background4.jpg)"> 
<big><big><center>HOSPITAL&nbsp; MANAGEMENT SYSTEM<center><br>
<br>
<br>
</big></big>
<center>
<h2 align="center">Prescription List</h2>
<table align="center" border="1" cellspacing="0" cellpadding="0" width="700">
<thead>
	<th>Patient Id</th>
	<th>Medicine</th>
	<th>Diagnosis</th>
	<th>Instruction</th>
	<th>Doctor Name</th>
	<th>Action</th>
</thead>
</body>
</html>
<?php
$host='localhost';
$username='root';
$password='';
$dbname='hms';
$con=mysql_connect($host,$username,$password);
mysql_select_db($dbname);
$epr='';
$msg='';
if(isset($_GET['epr']))
	$epr=$_GET['epr'];
$sql=mysql_query("SELECT * FROM prescription");
	while($row=mysql_fetch_array($sql)){
		echo "<tr>
		<td>".$row['id']."</td>
		<td>".$row['medicine']."</td>
		<td>".$row['diagnosis']."</td>
		<td>".$row['instruction']."</td>
		<td>".$row['docname']."</td>
		<td align='center'>
			<a href='viewpres.php?epr=delete&id=".$row['id']."'>DELETE</a> | 
			<a href='viewpres.php?epr=update&id=".$row['id']."'>UPDATE</a>
		</td>
		</tr>";
}
//*****delete record*****
if($epr=='delete')
{
	$id=$_GET['id'];
	$delete=mysql_query("DELETE FROM prescription where id=$id");
	if($delete)
		header("location:viewpres.php");
	else
		$msg='Error : '.mysql_error();
}
//*****save update******
if($epr=='saveup')
{
	$id=$_POST['txtid'];
	$medicine=$_POST['txtmed'];
	$diagnosis=$_POST['txtdiag'];
	$instruction=$_POST['txtins'];
	$docname=$_POST['txtdocname'];
	$a_sql=mysql_query("UPDATE prescription SET medicine='$medicine',diagnosis='$diagnosis',instruction='$instruction',docname='$docname' where id='$id'");
	if($a_sql)
		header("location:viewpres.php");
	else
		$msg='Error : '.mysql_error();
}


?>
</table>
<?php
if($epr=='update'){
	$id=$_GET['id'];
	$row=mysql_query("SELECT * FROM prescription where id='$id'");
	$st_row=mysql_fetch_array($row);
?>
<h2 align="center">Update Doctor</h2>
<form method="Post" action='viewpres.php?epr=saveup'>
	<table align='center'>
	<tr>
		<td>Id: </td>
		<td><input type='text' name='txtid' value="<?php echo $st_row['id'] ?>"/></td>
	</tr>
	<tr>
		<td>Medicine: </td>
		<td><input type='text' name='txtmed' value="<?php echo $st_row['medicine'] ?>"/></td>
	</tr>
	<tr>
		<td>Diagnosis: </td>
		<td><input type='text' name='txtdiag' value="<?php echo $st_row['diagnosis'] ?>"/></td>
	</tr>
	<tr>
		<td>Instruction: </td>
		<td><input type='text' name='txtins' value="<?php echo $st_row['instruction'] ?>"/></td>
	</tr>
	<tr>
		<td>Doctor Name: </td>
		<td><input type='text' name='txtdocname' value="<?php echo $st_row['docname'] ?>"/></td>
	</tr>
	<tr>
		<td></td>
		<td><input type='submit' name='btnsave'/></td>
	</tr>
	</table>
</form>
<?php }else{ ?>

<?php } ?>

<br>
<br>
<br>
<a href="prescription.html"><b>BACK</b></a>