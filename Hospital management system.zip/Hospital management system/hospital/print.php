<?php
window.print();
?>