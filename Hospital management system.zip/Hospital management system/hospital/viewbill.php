<html> 
 <head>
 </head> 
<body style="background-image:url(background4.jpg)"> 
<big><big><center>HOSPITAL&nbsp; MANAGEMENT SYSTEM<center><br>
<br>
<br>
</big></big>
<center>
<h2 align="center">Bill List</h2>
<table align="center" border="1" cellspacing="0" cellpadding="0" width="700">
<thead>
	<th>Patient Id</th>
	<th>Patient Name</th>
	<th>Total</th>
	<th>Date</th>
</thead>
</body>
</html>
<?php
$host='localhost';
$username='root';
$password='';
$dbname='hms';
$total=0;
$con=mysql_connect($host,$username,$password);
mysql_select_db($dbname);
$sql=mysql_query("SELECT * FROM bill");
	while($row=mysql_fetch_array($sql)){
		echo "<tr>
		<td>".$row['id']."</td>
		<td>".$row['name']."</td>
		<td>".($total + $row["docfee"] + $row["medfee"] + $row["bedfee"] + $row["bldfee"])."</td> 
		<td>".$row['date']."</td>
		</tr>";
}
?>
<a href="bill.html"><b>BACK</b></a>