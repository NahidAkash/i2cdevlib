<html> 
 <head>
 </head> 
<body style="background-image:url(background4.jpg)"> 
<big><big><center>HOSPITAL&nbsp; MANAGEMENT SYSTEM<center><br>
<br>
<br>
</big></big>
<center>
<h2 align="center">Patient List</h2>
<table align="center" border="1" cellspacing="0" cellpadding="0" width="700">
<thead>
	<th>Patient Id</th>
	<th>Patient Name</th>
	<th>Age</th>
	<th>Gender</th>
	<th>Occupation</th>
	<th>Mobile</th>
	<th>Address</th>
	<th>Action</th>
</thead>
</body>
</html>
<?php
$host='localhost';
$username='root';
$password='';
$dbname='hms';
$con=mysql_connect($host,$username,$password);
mysql_select_db($dbname);
$epr='';
$msg='';
if(isset($_GET['epr']))
	$epr=$_GET['epr'];
$sql=mysql_query("SELECT * FROM patients");
$sno=1;
	while($row=mysql_fetch_array($sql)){
		echo "<tr>
		<td>".$sno."</td>
		<td>".$row['name']."</td>
		<td>".$row['age']."</td>
		<td>".$row['gender']."</td>
		<td>".$row['occupation']."</td>
		<td>".$row['mobile']."</td>
		<td>".$row['address']."</td>
		<td align='center'>
			<a href='viewpatients.php?epr=delete&id=".$row['id']."'>DELETE</a> | 
			<a href='viewpatients.php?epr=update&id=".$row['id']."'>UPDATE</a>
		</td>
		</tr>";
	$sno++;
}
//*****delete record*****
if($epr=='delete')
{
	$id=$_GET['id'];
	$delete=mysql_query("DELETE FROM patients where id=$id");
	if($delete)
		header("location:viewpatients.php");
	else
		$msg='Error : '.mysql_error();
}
//*****save update******
if($epr=='saveup')
{
	$id=$_POST['txtid'];
	$name=$_POST['txtname'];
	$age=$_POST['txtage'];
	$gender=$_POST['txtgender'];
	$occupation=$_POST['txtoccupation'];
	$mobile=$_POST['txtmobile'];
	$address=$_POST['txtaddress'];
	$a_sql=mysql_query("UPDATE patients SET name='$name',age='$age',gender='$gender',occupation='$occupation',mobile='$mobile',address='$address' where id='$id'");
	if($a_sql)
		header("location:viewpatients.php");
	else
		$msg='Error : '.mysql_error();
}


?>
</table>
<?php
if($epr=='update'){
	$id=$_GET['id'];
	$row=mysql_query("SELECT * FROM patients where id='$id'");
	$st_row=mysql_fetch_array($row);
?>
<h2 align="center">Update Patient</h2>
<form method="Post" action='viewpatients.php?epr=saveup'>
	<table align='center'>
	<tr>
		<td>Id: </td>
		<td><input type='text' name='txtid' value="<?php echo $st_row['id'] ?>"/></td>
	</tr>
	<tr>
		<td>Name: </td>
		<td><input type='text' name='txtname' value="<?php echo $st_row['name'] ?>"/></td>
	</tr>
	<tr>
		<td>Age: </td>
		<td><input type='text' name='txtage' value="<?php echo $st_row['age'] ?>"/></td>
	</tr>
	<tr>
		<td>Gender: </td>
		<td><input type='text' name='txtgender' value="<?php echo $st_row['gender'] ?>"/></td>
	</tr>
	<tr>
		<td>Occupation: </td>
		<td><input type='text' name='txtoccupation' value="<?php echo $st_row['occupation'] ?>"/></td>
	</tr>
	<tr>
		<td>Mobile: </td>
		<td><input type='text' name='txtmobile' value="<?php echo $st_row['mobile'] ?>"/></td>
	</tr>
	<tr>
		<td>Address: </td>
		<td><input type='text' name='txtaddress' value="<?php echo $st_row['address'] ?>"/></td>
	</tr>
	<tr>
		<td></td>
		<td><input type='submit' name='btnsave'/></td>
	</tr>
	</table>
</form>
<?php }else{ ?>

<?php } ?>

<br>
<br>
<br>
<a href="home.html"><b>HOME</b></a>