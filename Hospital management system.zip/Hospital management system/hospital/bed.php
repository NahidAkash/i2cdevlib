<html> 
 <head>
 </head> 
<body style="background-image:url(background4.jpg)"> 
<big><big><center>HOSPITAL&nbsp; MANAGEMENT SYSTEM<center><br>
<br>
<br>
</big></big>
<center>
<h2 align="center">Ward1 List</h2>
<table align="center" border="1" cellspacing="0" cellpadding="0" width="700">
<thead>
	<th>Bed No</th>
	<th>Patient Name</th>
	<th>Date</th>
	<th>Action</th>
</thead>
</body>
</html>
<?php
$host='localhost';
$username='root';
$password='';
$dbname='hms';
$con=mysql_connect($host,$username,$password);
mysql_select_db($dbname);
$epr='';
$msg='';
if(isset($_GET['epr']))
	$epr=$_GET['epr'];
$sql=mysql_query("SELECT * FROM bed1");
	while($row=mysql_fetch_array($sql)){
		echo "<tr>
		<td>".$row['id']."</td>
		<td>".$row['patname']."</td>
		<td>".$row['date']."</td>
		<td align='center'> 
			<a href='bed.php?epr=update&id=".$row['id']."'>UPDATE</a>
		</td>
		</tr>";
}
//*****save update******
if($epr=='saveup')
{
	$id=$_POST['txtid'];
	$patname=$_POST['txtpatname'];
	$date=$_POST['txtdate'];
	$a_sql=mysql_query("UPDATE bed1 SET patname='$patname',date='$date' where id='$id'");
	if($a_sql)
		header("location:bed.php");
	else
		$msg='Error : '.mysql_error();
}


?>
</table>
<?php
if($epr=='update'){
	$id=$_GET['id'];
	$row=mysql_query("SELECT * FROM bed1 where id='$id'");
	$st_row=mysql_fetch_array($row);
?>
<h2 align="center">Update Bed</h2>
<form method="Post" action='bed.php?epr=saveup'>
	<table align='center'>
	<tr>
		<td>Id: </td>
		<td><input type='text' name='txtid' value="<?php echo $st_row['id'] ?>"/></td>
	</tr>
	<tr>
		<td>Patient Name: </td>
		<td><input type='text' name='txtpatname' value="<?php echo $st_row['patname'] ?>"/></td>
	</tr>
	<tr>
		<td>Date: </td>
		<td><input type='date' name='txtdate' value="<?php echo $st_row['date'] ?>"/></td>
	</tr>
	<tr>
		<td></td>
		<td><input type='submit' name='btnsave'/></td>
	</tr>
	</table>
</form>
<?php }else{ ?>

<?php } ?>

<br>
<br>
<br>
<a href="home.html"><b>BACK</b></a>
<a href="bed2.php"><b>NEXT</b></a>