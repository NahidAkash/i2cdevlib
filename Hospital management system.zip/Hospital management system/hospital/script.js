function myMap() {
    var mapOptions = {
        center: new google.maps.LatLng(23.809591, 90.367447),
        zoom: 20,
        mapTypeId: google.maps.MapTypeId.HYBRID
    }
var map = new google.maps.Map(document.getElementById("map"), mapOptions);
}