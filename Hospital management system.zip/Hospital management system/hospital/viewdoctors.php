<html> 
 <head>
 </head> 
<body style="background-image:url(background4.jpg)"> 
<big><big><center>HOSPITAL&nbsp; MANAGEMENT SYSTEM<center><br>
<br>
<br>
</big></big>
<center>
<h2 align="center">Doctors List</h2>
<table align="center" border="1" cellspacing="0" cellpadding="0" width="700">
<thead>
	<th>Id</th>
	<th>Name</th>
	<th>Specification</th>
	<th>Action</th>
</thead>
</body>
</html>
<?php
$host='localhost';
$username='root';
$password='';
$dbname='hms';
$con=mysql_connect($host,$username,$password);
mysql_select_db($dbname);
$epr='';
$msg='';
if(isset($_GET['epr']))
	$epr=$_GET['epr'];
$sql=mysql_query("SELECT * FROM doctors");
$sno=1;
	while($row=mysql_fetch_array($sql)){
		echo "<tr>
		<td>".$sno."</td>
		<td>".$row['name']."</td>
		<td>".$row['specification']."</td>
		<td align='center'>
			<a href='viewdoctors.php?epr=delete&id=".$row['id']."'>DELETE</a> | 
			<a href='viewdoctors.php?epr=update&id=".$row['id']."'>UPDATE</a>
		</td>
		</tr>";
	$sno++;
}
//*****delete record*****
if($epr=='delete')
{
	$id=$_GET['id'];
	$delete=mysql_query("DELETE FROM doctors where id=$id");
	if($delete)
		header("location:viewdoctors.php");
	else
		$msg='Error : '.mysql_error();
}
//*****save update******
if($epr=='saveup')
{
	$id=$_POST['txtid'];
	$name=$_POST['txtname'];
	$specification=$_POST['txtspecification'];
	$a_sql=mysql_query("UPDATE doctors SET name='$name',specification='$specification' where id='$id'");
	if($a_sql)
		header("location:viewdoctors.php");
	else
		$msg='Error : '.mysql_error();
}


?>
</table>
<?php
if($epr=='update'){
	$id=$_GET['id'];
	$row=mysql_query("SELECT * FROM doctors where id='$id'");
	$st_row=mysql_fetch_array($row);
?>
<h2 align="center">Update Doctor</h2>
<form method="Post" action='viewdoctors.php?epr=saveup'>
	<table align='center'>
	<tr>
		<td>Id: </td>
		<td><input type='text' name='txtid' value="<?php echo $st_row['id'] ?>"/></td>
	</tr>
	<tr>
		<td>Name: </td>
		<td><input type='text' name='txtname' value="<?php echo $st_row['name'] ?>"/></td>
	</tr>
	<tr>
		<td>Specification: </td>
		<td><input type='text' name='txtspecification' value="<?php echo $st_row['specification'] ?>"/></td>
	</tr>
	<tr>
		<td></td>
		<td><input type='submit' name='btnsave'/></td>
	</tr>
	</table>
</form>
<?php }else{ ?>

<?php } ?>

<br>
<br>
<br>
<a href="home.html"><b>HOME</b></a>