<?php
session_start();
?>


<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn = mysql_connect($dbhost, $dbuser, $dbpass);
$id=$_POST['id'];
$name=$_POST['name'];
$docfee=$_POST['docfee'];
$medfee=$_POST['medfee'];
$bedfee=$_POST['bedfee'];
$bldfee=$_POST['bldfee'];
$date=$_POST['date'];

mysql_select_db('hms');
$str="insert into bill values('$id','$name','$docfee','$medfee','$bedfee','$bldfee','$date')";

$res=@mysql_query($str)or die(mysql_error());
if($res>=0)
{ 
echo'<br><br>';
}
if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}
$id = $_POST['id']; 
$sql="SELECT * FROM patients WHERE id='$id'";


$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not get data: ' . mysql_error());
}
while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
	echo "<big><b>Bill : </b></big><br><br><br>";
	echo "<b>Patient Details : </b><br>";
    echo "PATIENT ID : {$row['id']}  <br><br> ".
         "NAME 		 : {$row['name']} <br><br> ".
         "AGE		 : {$row['age']} <br><br> ".
         "GENDER	 : {$row['gender']} <br><br> ".
         "MOBILE	 : {$row['mobile']} <br><br> ".
        
         "--------------------------------<br>";
}
$total=0;
   echo "DOCTOR FEE : $docfee <br><br>".
		"MEDICAL FEE: $medfee <br><br>".
		"BED FEE    : $bedfee <br><br>".
	    "BLOOD FEE  : $bldfee <br><br>".
		"Total      :". $total + $docfee + $medfee + $bedfee + $bldfee ."<br><br>".	
	     "--------------------------------<br>";
		 
mysql_close($conn);
?>
<html>
<input type="button" onClick="window.print();" value="Print Bill"/><br><br>
<a href="bill.html"><b>BACK</b></a>
</html>
