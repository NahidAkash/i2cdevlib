<html> 
 <head>
 </head> 
<body style="background-image:url(background4.jpg)"> 
<big><big><center>HOSPITAL&nbsp; MANAGEMENT SYSTEM<center><br>
<br>
<br>
</big></big>
<center>
<tr><td><table width=750 cellspacing=0 cellpadding=5> 
<tr bgcolor=#ccccc><td align=center>D No</td><td align=center>Doctor 
Name</td><td align=center>Specification</td><td align=center>Option</td></tr>
<?php
$conn=mysql_connect("localhost","root","");
	 if(!$conn)
		die("database connection failed".mysql_error());
	 else
		echo("Doctor List"."<br>");
$sql = 'SELECT * from doctors';

mysql_select_db('hms');
$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not get data: ' . mysql_error());
}
$sno=1;
while($row = mysql_fetch_array($retval))
{
echo "<tr><td>$sno</td><td>$row[1]</td><td>$row[2]</td><td><a 
href=docmod.php?rno=".$row[0].">Modify</a> | <a 
href=ddel.php?rno=".$row[0].">Delete</a></td></tr>"; 
 $sno++; 
} 
 
mysql_close($conn);
?>
